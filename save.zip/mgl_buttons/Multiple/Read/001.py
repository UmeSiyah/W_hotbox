#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Set Localize
#
#----------------------------------------------------------------------------------------------------------

# author: sbaykal

for Rn in nuke.selectedNodes():
    Rn['cacheLocal'].setValue(0)
