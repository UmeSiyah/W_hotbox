#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Scale : Y*-1
#
#----------------------------------------------------------------------------------------------------------

OLD_VALUE = nuke.selectedNode()['scale'].getValue()
if isinstance(OLD_VALUE, list):
    nuke.selectedNode()['scale'].setValue([OLD_VALUE[0], OLD_VALUE[1]*-1])
else:
    nuke.selectedNode()['scale'].setValue([OLD_VALUE, OLD_VALUE*-1])