#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Swap to / from
#
#----------------------------------------------------------------------------------------------------------

# author: sbaykal

SELECTED_NODE = nuke.selectedNode()
TO_KNOB = ['to1','to2','to3','to4']
FROM_KNOB = ['from1','from2','from3','from4']

TO_LIST = []
FROM_LIST = []

#Get all knob

for _to_knob in TO_KNOB:
    TO_LIST.append(SELECTED_NODE.knob(_to_knob).toScript())

for _from_knob in FROM_KNOB:
    FROM_LIST.append(SELECTED_NODE.knob(_from_knob).toScript())

#Set knob

for _to_knob in TO_KNOB:
    for newKnob in FROM_LIST:
        SELECTED_NODE.knob(_to_knob).fromScript(newKnob)
for _from_knob in FROM_KNOB:
    for newKnob in TO_LIST:
        SELECTED_NODE.knob(_from_knob).fromScript(newKnob)
