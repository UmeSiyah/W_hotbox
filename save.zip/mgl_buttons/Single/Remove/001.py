#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Keep RGBA
#
#----------------------------------------------------------------------------------------------------------

node = nuke.selectedNode()
node['operation'].setValue(1)
node['channels'].setValue('rgba')