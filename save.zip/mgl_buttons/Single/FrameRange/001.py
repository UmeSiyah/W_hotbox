#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Set playback range
#
#----------------------------------------------------------------------------------------------------------

# author: sbaykal

n = nuke.selectedNode()
vRange = nuke.toNode('Viewer1')['frame_range']

vRange.setText(f"{int(n['first_frame'].getValue())}-{int(n['last_frame'].getValue())}")
