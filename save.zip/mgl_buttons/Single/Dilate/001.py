#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Inverse
#
#----------------------------------------------------------------------------------------------------------

# author: sbaykal

n = nuke.selectedNode()
value = str( 'size ' + str ( int ( n['size'].getValue() ) * -1 ) )
nuke.createNode( n.Class(), value )
