#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Clamp
#
#----------------------------------------------------------------------------------------------------------

# author: sbaykal
# divise by 2 the height and crop to the top part

for i in nuke.selectedNodes():
	i.knob('black_clamp').setValue(1-i.knob('black_clamp').value())
	i.knob('white_clamp').setValue(i.knob('black_clamp').value())
