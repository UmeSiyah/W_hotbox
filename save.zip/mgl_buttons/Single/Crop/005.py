#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Top
#
#----------------------------------------------------------------------------------------------------------

# author: sbaykal
# divise by 2 the height and crop to the top part

format = nuke.Root().format().height()
box_knob = nuke.selectedNode()['box']
#top
box_knob.setY(format/2)
box_knob.setT(format)
