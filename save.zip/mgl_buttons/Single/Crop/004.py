#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Bottom
#
#----------------------------------------------------------------------------------------------------------

# author: sbaykal
# divise by 2 the height and crop to the bottom part

format = nuke.Root().format().height()
box_knob = nuke.selectedNode()['box']
#bottom
box_knob.setY((0))
box_knob.setT((format/2))
