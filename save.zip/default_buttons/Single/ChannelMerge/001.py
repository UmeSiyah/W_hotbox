#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Multiply
#
#----------------------------------------------------------------------------------------------------------

for i in nuke.selectedNodes():
	i.knob('operation').setValue('mulitply')